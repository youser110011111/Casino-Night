// Recuperar o saldo do armazenamento local, se existir
let saldo = parseFloat(localStorage.getItem('saldo')) || 0;

// Recuperar o nome do usuário do armazenamento local, se existir
let nomeUsuario = localStorage.getItem('nomeUsuario');

// Variável para armazenar o PIN
const pin = "1234"; // Altere para o seu PIN desejado

// Função para atualizar o saldo na página
function atualizarSaldo() {
    document.getElementById('saldo').innerText = `${saldo.toFixed(2)} $`;
}

// Função para registrar o nome do usuário
function registrarNome() {
    nomeUsuario = document.getElementById('nome').value;
    if (nomeUsuario.trim() === "") {
        alert('Please, insert your name.');
        return;
    }

    // Salvar o nome do usuário no armazenamento local
    localStorage.setItem('nomeUsuario', nomeUsuario);

    // Atualizar o título da carteira virtual com o nome do usuário
    const tituloCarteira = document.querySelector('h1');
    tituloCarteira.innerText = `${nomeUsuario}'s Virtual Wallet`;

    // Exibir a carteira virtual após o registro do nome
    document.getElementById('formularioNome').style.display = 'none';
    document.getElementById('carteiraVirtual').style.display = 'block';
}

// Verificar se o nome do usuário já foi registrado
if (!nomeUsuario) {
    // Exibir o formulário de inscrição
    document.getElementById('formularioNome').style.display = 'block';
} else {
    // Atualizar o título da carteira virtual com o nome do usuário
    const tituloCarteira = document.querySelector('h1');
    tituloCarteira.innerText = `${nomeUsuario}'s Virtual Wallet`;

    // Exibir a carteira virtual
    document.getElementById('carteiraVirtual').style.display = 'block';
}

// Adicionar dinheiro ao saldo
document.getElementById('acrescentar').addEventListener('click', function() {
    const inputPIN = solicitarPIN();
    if (inputPIN === pin) {
        const valor = parseFloat(prompt('Digit the amount you want to deposit:'));
        if (!isNaN(valor) && valor >= 0) {
            saldo += valor;
            // Salvar o saldo atual no armazenamento local
            localStorage.setItem('saldo', saldo);
            atualizarSaldo();
            adicionarTransacao('deposit', valor); // Adicionar transação ao histórico
        } else {
            alert('Invalid Value!');
        }
    } else {
        alert('Incorrect Pin!');
    }
});

// Tirar dinheiro do saldo
document.getElementById('tirar').addEventListener('click', function() {
    const inputPIN = solicitarPIN();
    if (inputPIN === pin) {
        const valor = parseFloat(prompt('Digit the amount you want to withdraw:'));
        if (!isNaN(valor) && valor >= 0) {
            if (saldo >= valor) {
                saldo -= valor;
                // Salvar o saldo atual no armazenamento local
                localStorage.setItem('saldo', saldo);
                atualizarSaldo();
                adicionarTransacao('withdrawal', valor); // Adicionar transação ao histórico
            } else {
                alert('Insufficient Credits!');
            }
        } else {
            alert('Invalid Value!');
        }
    } else {
        alert('Incorrect Pin!');
    }
});

// Função para solicitar o PIN ao usuário
function solicitarPIN() {
    return prompt('Digit the Pin:');
}

// Função para adicionar uma transação ao histórico
function adicionarTransacao(type, amount) {
    // Recuperar o histórico de transações do armazenamento local
    let historico = JSON.parse(localStorage.getItem('historico')) || [];
    // Obter a data e hora atual
    const now = new Date();
    // Formatar a data e hora
    const formattedDateTime = now.toLocaleString();
    // Adicionar a nova transação ao histórico
    historico.push({ type, amount, dateTime: formattedDateTime });
    // Salvar o histórico atualizado no armazenamento local
    localStorage.setItem('historico', JSON.stringify(historico));
}


// Função para exibir o histórico de transações
function exibirHistorico() {
    // Recuperar o histórico de transações do armazenamento local
    const historico = JSON.parse(localStorage.getItem('historico')) || [];
    
    // Criar o conteúdo do popup com as transações
    let historicoHTML = 'Transaction History:\n';
    historico.forEach(transaction => {
        historicoHTML += `${transaction.type === 'deposit' ? '+' : '-'} ${transaction.amount.toFixed(2)}\n`;
    });
    
    // Exibir o histórico de transações no alerta
    alert(historicoHTML);
}

// Atualizar saldo inicialmente
atualizarSaldo();
